<?php
return [
    'welcom' => "Welcome",
]
?>;