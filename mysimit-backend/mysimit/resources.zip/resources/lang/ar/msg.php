<?php
return [
    'welcom' => "خوش آمدید",
]
?>;