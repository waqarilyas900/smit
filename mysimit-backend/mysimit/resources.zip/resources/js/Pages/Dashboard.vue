<template>
	<app-layout title="Dashboard">
		<div class="">
			<div class="mx-auto px-4">
				<h1 class="font-bold text-2xl">Dashboard</h1>
			</div>
			<div class="mx-auto px-4">
				<!-- Replace with your content -->
				<div class="py-4">
					<div class="border-4 border-dashed border-gray-200 rounded-lg h-96" />
				</div>
				<!-- /End replace -->
			</div>
		</div>
	</app-layout>
</template>

<script>
import AppLayout from "@/Layouts/AppLayout.vue";

export default {
	components: {
		AppLayout,
	},
};
</script>
