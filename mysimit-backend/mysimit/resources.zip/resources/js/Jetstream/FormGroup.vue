<template>
	<div>
		<div class="flex flex-col md:flex-row w-full lg:w-10/12 xl:w-9/12 px-4 py-5">
			<slot></slot>
		</div>
	</div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>