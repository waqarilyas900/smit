<template>
    <div class="bg-white shadow rounded-md overflow-hidden p-4">
        <slot></slot>
    </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>
